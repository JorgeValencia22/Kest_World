// Descripción del avatar y validación contra el inventario del usuario.
import { SHOP_BY_ID } from './catalog.js';

export const SKIN_TONES = ['#ffdbac', '#f1c27d', '#e0ac69', '#c68642', '#8d5524', '#5c3a1e', '#ffe0bd', '#f5d0c5'];

export const DEFAULT_AVATAR = {
  skin: '#f1c27d',
  hair: 'hair_short',
  hairColor: '#4e342e',
  shirt: 'shirt_tee',
  shirtColor: '#2196f3',
  pants: 'pants_jeans',
  pantsColor: '#37474f',
  shoesColor: '#212121',
  face: 'face_smile',
  accessories: [],
  effect: null,
};

const HEX = /^#[0-9a-fA-F]{6}$/;
const color = (v, def) => (HEX.test(v) ? v.toLowerCase() : def);

/**
 * Normaliza un avatar. Los objetos que no pertenecen a `owned` (Set de ids)
 * se sustituyen por los valores por defecto.
 */
export function sanitizeAvatar(a, owned) {
  a = a && typeof a === 'object' ? a : {};
  const d = DEFAULT_AVATAR;
  const has = (id, type) => {
    const item = SHOP_BY_ID[id];
    return item && item.type === type && (item.price === 0 || (owned && owned.has(id)));
  };
  const out = {
    skin: color(a.skin, d.skin),
    hair: a.hair === 'none' ? 'none' : has(a.hair, 'hair') ? a.hair : d.hair,
    hairColor: color(a.hairColor, d.hairColor),
    shirt: has(a.shirt, 'shirt') ? a.shirt : d.shirt,
    shirtColor: color(a.shirtColor, d.shirtColor),
    pants: has(a.pants, 'pants') ? a.pants : d.pants,
    pantsColor: color(a.pantsColor, d.pantsColor),
    shoesColor: color(a.shoesColor, d.shoesColor),
    face: has(a.face, 'face') ? a.face : d.face,
    accessories: [],
    effect: a.effect && has(a.effect, 'effect') ? a.effect : null,
  };
  if (Array.isArray(a.accessories)) {
    for (const id of a.accessories) {
      if (out.accessories.length >= 4) break;
      if (has(id, 'accessory') && !out.accessories.includes(id)) out.accessories.push(id);
    }
  }
  return out;
}
